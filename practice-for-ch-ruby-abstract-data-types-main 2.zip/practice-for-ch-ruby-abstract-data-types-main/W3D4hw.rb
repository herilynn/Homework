class Stack
    def initialize
        @storage = []
    end

    def storage
        @storage
    end

    def push(el)
        @storage.push(el)
    end

    def pop
        @storage.pop
    end

    def peek
        @storage[0]
    end
end

class Queue
    def initialize
        @storage = []
    end

    def storage
        @storage
    end

    def enqueue(el)
        @storage.unshift(el)
    end

    def dequeue
        @storage.pop
    end

    def peek
        @storage[0]
    end
end

class Map
    def initialize
        @storage = []
    end

    def storage
        @storage
    end

    def set(key, value)
        @storage.each do |keys|
            if keys[0] == key
                keys[1] = value
            end 
        @storage.unshift([key, value])
    end

    def get(key)
        @storage.each do |keys|
            if keys[0] == key
                return keys[1]
            end
        end
    end

    def delete(key)
        @storage.each do |keys|
            if keys[0] == key
                @storage.delete(key)
            end
        end
    end

    def show
        @storage[0]
    end
end